﻿window.selectedWorkout = null;

function setWorkout(workout) {
    window.selectedWorkout = workout;
}