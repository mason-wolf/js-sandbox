let router = document.querySelector('router-outlet');

router.addRoute("workouts", WorkoutsComponent);
router.addRoute("add-workout", AddWorkoutComponent);
router.addRoute("dashboard", DashboardComponent);

router.navigate("workouts");
