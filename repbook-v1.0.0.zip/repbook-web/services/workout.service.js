﻿class WorkoutService {
    
    workouts = [];

    getWorkouts() {
        const workoutsJSON = localStorage.getItem("workouts");
        if (workoutsJSON) {
            const workoutsData = JSON.parse(workoutsJSON);
            this.workouts = workoutsData.map(workoutData => {
                const workout = new Workout();
                Object.assign(workout, workoutData);
            
                if (workoutData.exercises) {
                    workout.exercises = workoutData.exercises.map(exerciseData => {
                        const exercise = new Exercise();
                        return Object.assign(exercise, exerciseData);
                    });
                }
            
                if (workoutData.cardio) {
                    workout.cardio = workoutData.cardio.map(cardioData => {
                        const cardio = new Cardio();
                        return Object.assign(cardio, cardioData);
                    });
                }
            
                return workout;
            });
        } else {
            this.workouts = [];
        }
        return this.workouts;
    }

    saveWorkout(workout) {
        this.getWorkouts();
        this.workouts.push(workout);
        const workoutsJson = JSON.stringify(this.workouts);
        localStorage.setItem("workouts", workoutsJson);
    }

    updateWorkout(updatedWorkout) {
  
        this.getWorkouts();
        const index = this.workouts.findIndex(workout => workout.id === updatedWorkout.id);

        if (index !== -1) {

            this.workouts[index] = updatedWorkout;
            const workoutsJson = JSON.stringify(this.workouts);
            localStorage.setItem("workouts", workoutsJson);
        } else {
            alert("Workout not found for update:", updatedWorkout);
        }
    }

    deleteWorkout(workoutId) {

        this.getWorkouts();

        const filteredWorkouts = this.workouts.filter(workout => workout.id !== workoutId);

        if (filteredWorkouts.length === this.workouts.length) {
            alert("Workout not found for deletion.");
            return;
        }

        this.workouts = filteredWorkouts;
        const workoutsJson = JSON.stringify(this.workouts);
        localStorage.setItem("workouts", workoutsJson);
    }

}

