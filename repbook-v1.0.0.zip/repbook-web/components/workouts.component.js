﻿class WorkoutsComponent extends HTMLElement {
  workouts;
  workoutService;

  connectedCallback() {
    this.workoutService = new WorkoutService();
    this.workouts = this.workoutService.getWorkouts();

    this.render();
    this.registerEvents();
  }

  render() {
    this.innerHTML = `
            <div class="workouts">
                <h1>Workouts</h1>
                <button id="addWorkout" class="primary" style="margin-bottom:10px;margin-top:-25px;">Add Workout</button>
                <div id="workoutList"></div>
            </div>
        `;
  }

  sortWorkoutsByDateDesc() {
    this.workouts.sort((a, b) => {
      const dateA = new Date(a.date);
      const dateB = new Date(b.date);
      return dateB - dateA;
    });
  }

  showWorkouts() {
    const workoutList = this.querySelector('#workoutList');
    if (!workoutList) return;

    this.sortWorkoutsByDateDesc();

    let tableRows = '';
    for (let i = 0; i < this.workouts.length; i++) {
      const workout = this.workouts[i];
      tableRows += `
                <tr>
                    <td>
                        <a href="#">
                            <span class="edit-workout" workout-id="${workout.id}">${workout.name}</span>
                        </a>
                    </td>
                    <td>${workout.date}</td>
                </tr>
            `;
    }

    if (this.workouts.length > 0) {
      workoutList.innerHTML = `
            <table style="margin-top:10px;">
                <tr>
                    <th>Name</th>
                    <th>Date</th>
                </tr>
                ${tableRows}
            </table>
        `;
    } else {
        workoutList.innerHTML = `
            <div class="no-workouts">
            No workouts yet!
            </div>
        `;
    }

    const editButtons = workoutList.querySelectorAll('.edit-workout');
    editButtons.forEach(button => {
      button.addEventListener('click', event => {
        const id = event.target.getAttribute('workout-id');
        const workout = this.workouts.find(w => w.id === id);
        setWorkout(workout);
        router.navigate('add-workout');
      });
    });
  }

  registerEvents() {
    const addWorkoutBtn = this.querySelector('#addWorkout');
    if (addWorkoutBtn) {
      addWorkoutBtn.addEventListener('click', () => {
        window.selectedWorkout = null;
        router.navigate('add-workout');
      });
    }
    this.showWorkouts();
  }
}

customElements.define('workouts-component', WorkoutsComponent);
