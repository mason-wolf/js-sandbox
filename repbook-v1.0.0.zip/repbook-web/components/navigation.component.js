class NavComponent extends HTMLElement {
    connectedCallback() {
        this.innerHTML = `
            <div class="nav">
                <a href="javascript:void(0)" id="workouts-nav-link">Workouts</a>
                <a href="javascript:void(0)" id="export-data-link">
                    <img src="./images/export.png" class="icon" title="Export Data">
                </a>
                <img src="./images/import.png" class="icon" style="margin-right:15px;" title="Import Data">
            </div>
        `;

        const workoutsLink = this.querySelector("#workouts-nav-link");
        workoutsLink.addEventListener("click", () => {
            router.navigate("workouts");
        });

        const exportDataLink = this.querySelector("#export-data-link");
        exportDataLink.addEventListener("click", () => { 
            alert("Exporting data");
        });
    }
}

customElements.define("nav-component", NavComponent);
