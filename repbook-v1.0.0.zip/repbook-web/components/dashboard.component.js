﻿class DashboardComponent extends HTMLElement {
    connectedCallback() {
        this.innerHTML = `
            <div>
                <h1>Dashboard</h1>
                <p>No workouts added yet!</p>
            </div>
        `;
    }
}

customElements.define("dashboard-component", DashboardComponent);
