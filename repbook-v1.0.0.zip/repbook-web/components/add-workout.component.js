﻿class AddWorkoutComponent extends HTMLElement {
  workout;
  workoutService;

  constructor() {
    super();
    this.workoutService = new WorkoutService();
  }

  connectedCallback() {
    this.innerHTML = `
            <div class="workouts">
                <button id="backBtn">Back</button>
                <h1 id="addWorkoutHeader">Add Workout</h1>
                <div class="form-field">
                    Workout Name: <input id="workoutName">
                </div>

                <div class="form-field">
                    Type:
                    <select id="workoutType">
                        <option>Strength</option>
                        <option>Cardio</option>
                        <option>Strength/Cardio</option>
                    </select>
                </div>

                <div class="form-field">
                    Date: <input type="date" id="workoutDate">
                </div>

                <div class="form-field">
                    <button id="addExercise">Add Exercise</button>
                    <button id="addCardio">Add Cardio</button>
                </div>

                <!-- Exercises -->
                <div id="exerciseList"></div>

                <!-- Cardio -->
                <div id="cardioList"></div>

                <button class="primary" id="addWorkoutBtn">Add Workout</button>
                <button id="deleteWorkout" class="warning">Delete Workout</button>


                <!-- Add Exercise Modal -->
                <div id="add-exercise-modal" class="modal">
                    <div class="modal-content">
                        <button id="closeExerciseModal">X</button>
                        <h2>Add Exercise</h2>
                        <div class="form-field">
                           Name: <input type="text" id="exerciseName">
                        </div>
                        <div class="form-field">
                           Sets: <input type="text" id="sets">
                        </div>
                        <div class="form-field">
                           Reps: <input type="text" id="reps">
                        </div>
                        <button id="saveExerciseBtn">Add</button>
                    </div>
                </div>

                <!-- Add Cardio Modal -->
                <div id="add-cardio-modal" class="modal">
                    <div class="modal-content">
                        <button id="closeCardioModal">X</button>
                        <h2>Add Cardio</h2>
                        <div class="form-field">
                           Name: <input type="text" id="cardioName">
                        </div>
                        <div class="form-field">
                           Distance (Miles): <input type="text" id="distance">
                        </div>
                        <div class="form-field">
                           Time (00:00): <input type="text" id="time">
                        </div>
                        <button id="saveCardioBtn">Add</button>
                    </div>
                </div>
            </div>
        `;

        // Set default values.
        document.getElementById('workoutName').value = 'Untitled Workout';
        document.querySelector('input[type="date"]').valueAsDate = new Date();
        const workoutType = document.getElementById("workoutType");
        workoutType.addEventListener('change', () => {
            const selectedValue = workoutType.value;
            this.workout.type = selectedValue;
        });
        workoutType.value = "Strength";
        // Register events.
        this.registerEvents();
  }

  resetForm() {
    document.getElementById('exerciseName').value = '';
    document.getElementById('sets').value = '';
    document.getElementById('reps').value = '';
    document.getElementById('cardioName').value = '';
    document.getElementById('distance').value = '';
    document.getElementById('time').value = '';
  }

  delete(id) {
    alert('deleting ' + id);
  }

  removeExercise(exerciseId) {
    this.workout.exercises = this.workout.exercises.filter(
      exercise => exercise.id !== exerciseId
    );
    this.showExercises();
  }

  removeCardio(cardioId) {
    this.workout.cardio = this.workout.cardio.filter(
      cardio => cardio.id !== cardioId
    );
    this.showCardio();
  }

  showExercises() {
    const exerciseList = document.getElementById('exerciseList');
    let tableRows = '';
    for (let i = 0; i < this.workout.exercises.length; i++) {
      const exercise = this.workout.exercises[i];
      tableRows += `
                <tr>
                    <td>${exercise.name}</td>
                    <td>${exercise.sets}</td>
                    <td>${exercise.reps}</td>
                    <td style='text-align:center;'>
                    <a href="#">
                        <span class="delete-item" exercise-id="${exercise.id}">X</span>
                    </a>
                    </td>
                </tr>
            `;
    }

    exerciseList.innerHTML = `
            <h2>Exercises</h2>
            <table>
                <tr>
                    <th>Exercise</th>
                    <th>Sets</th>
                    <th>Reps</th>
                    <th></th>
                </tr>
                ${tableRows}
            </table>
        `;

    const deleteButtons = exerciseList.querySelectorAll('.delete-item');
    deleteButtons.forEach(button => {
      button.addEventListener('click', event => {
        const id = event.target.getAttribute('exercise-id');
        this.removeExercise(id);
      });
    });
  }

  showCardio() {
    const cardioList = document.getElementById('cardioList');
    let tableRows = '';
    for (let i = 0; i < this.workout.cardio.length; i++) {
      const cardio = this.workout.cardio[i];
      tableRows += `
                <tr>
                    <td>${cardio.name}</td>
                    <td>${cardio.distance}</td>
                    <td>${cardio.time}</td>
                    <td style='text-align:center;'>
                        <a href="#">
                            <span class="delete-item" cardio-id="${cardio.id}">X</span>
                        </a>
                    </td>
                </tr>
            `;
    }

    cardioList.innerHTML = `
            <h2>Cardio</h2>
            <table>
                <tr>
                    <th>Name</th>
                    <th>Distance</th>
                    <th>Time</th>
                    <th></th>
                </tr>
                ${tableRows}
            </table>
        `;

    const deleteButtons = cardioList.querySelectorAll('.delete-item');
    deleteButtons.forEach(button => {
      button.addEventListener('click', event => {
        const id = event.target.getAttribute('cardio-id');
        this.removeCardio(id);
      });
    });
  }

  registerAddExerciseForm() {
    // Open add exercise modal.
    const exerciseModal = document.getElementById('add-exercise-modal');
    const closeExerciseModal = document.getElementById('closeExerciseModal');

    // Show add exercise modal.
    const addExercise = document.getElementById('addExercise');
    addExercise.addEventListener('click', () => {
      exerciseModal.style.display = 'flex';
      let exercise = new Exercise('test', 1, 1);
    });

    // Close add exercise modal.
    closeExerciseModal.addEventListener('click', () => {
      exerciseModal.style.display = 'none';
    });

    // Save exercise.
    const saveExercise = document.getElementById('saveExerciseBtn');
    saveExercise.addEventListener('click', () => {
      let exercise = new Exercise();
      exercise.name = document.getElementById('exerciseName').value;
      exercise.sets = document.getElementById('sets').value;
      exercise.reps = document.getElementById('reps').value;
      exercise.workoutId = this.workoutId;
      this.workout.exercises.push(exercise);
      exerciseModal.style.display = 'none';
      this.resetForm();
      this.showExercises();
    });
  }

  registerAddCardioForm() {
    // Open add exercise modal.
    const cardioModal = document.getElementById('add-cardio-modal');
    const closeCardioModal = document.getElementById('closeCardioModal');

    // Show add cardio modal.
    const addCardio = document.getElementById('addCardio');
    addCardio.addEventListener('click', () => {
      cardioModal.style.display = 'flex';
    });

    // Close add cardio modal.
    closeCardioModal.addEventListener('click', () => {
      cardioModal.style.display = 'none';
    });

    // Save Cardio.
    const saveCardio = document.getElementById('saveCardioBtn');
    saveCardio.addEventListener('click', () => {
      let cardio = new Cardio();
      cardio.name = document.getElementById('cardioName').value;
      cardio.distance = document.getElementById('distance').value;
      cardio.time = document.getElementById('time').value;
      cardio.workoutId = this.workout.id;
      this.workout.cardio.push(cardio);
      cardioModal.style.display = 'none';
      let cardioJson = JSON.stringify(cardio);
      this.resetForm();
      this.showCardio();
    });
  }

  registerAddWorkoutForm() {
    const addWorkoutBtn = document.getElementById('addWorkoutBtn');
    addWorkoutBtn.addEventListener('click', () => {
      this.workout.name = document.getElementById('workoutName').value;
      this.workout.date = document.getElementById('workoutDate').value;
      this.workoutService.saveWorkout(this.workout);
      router.navigate('workouts');
    });
  }

  enableEditMode() {
      Object.assign(this.workout, window.selectedWorkout);
      try {
        document.getElementById("addWorkoutHeader").innerText = "Edit Workout";
        document.getElementById("workoutName").value = this.workout.name;
        document.getElementById("workoutDate").value = this.workout.date;
        document.getElementById("workoutType").value = this.workout.type;
        document.getElementById("addWorkoutBtn").innerHTML = "Save Workout";
        document.getElementById("deleteWorkout").style.display = "block";
        const addWorkoutBtn = document.getElementById("addWorkoutBtn");
    
        addWorkoutBtn.replaceWith(addWorkoutBtn.cloneNode(true));

        const newAddWorkoutBtn = document.getElementById("addWorkoutBtn");

        // Update button.
        newAddWorkoutBtn.addEventListener('click', () => {
          this.workout.name = document.getElementById('workoutName').value;
          this.workout.date = document.getElementById('workoutDate').value;
          this.workoutService.updateWorkout(this.workout);
          window.selectedWorkout = null;
          router.navigate('workouts');
        });

        // Delete button.
        const deleteWorkoutBtn = document.getElementById("deleteWorkout");
        deleteWorkoutBtn.addEventListener('click', () => {
            this.workoutService.deleteWorkout(this.workout.id);
            router.navigate('workouts');
        });

        this.showExercises();
        this.showCardio();
      } catch (e) {
        alert(e); 
      } 
  }

  registerEvents() {
    this.registerAddExerciseForm();
    this.registerAddCardioForm();
    this.workout = new Workout();
    this.workout.id = generateGUID();
    this.registerAddWorkoutForm();

    const backBtn = document.getElementById("backBtn");
    backBtn.addEventListener('click', () => {
        router.navigate('workouts');
    });

    if (window.selectedWorkout) {
        this.enableEditMode();
    }
  }
}

customElements.define('add-workout-component', AddWorkoutComponent);
