﻿class Router extends HTMLElement {

    constructor() {
        super();
        this.routes = new Map();
    }

    connectedCallback() {
        this.innerHTML = '<div id="route-view"></div>';
        this.routeView = this.querySelector('#route-view');
    }

    addRoute(routeName, componentClass) {
        this.routes.set(routeName, componentClass); 
    }

    navigate(routeName) {
        if (this.routes.has(routeName)) {
            this.routeView.innerHTML = ''; 
            const ComponentClass = this.routes.get(routeName);
            const componentInstance = new ComponentClass(); 
            this.routeView.appendChild(componentInstance); 
        } else {
            this.routeView.innerHTML = `<p>Route "${routeName}" not found.</p>`;
        }
    }

}

customElements.define("router-outlet", Router);
