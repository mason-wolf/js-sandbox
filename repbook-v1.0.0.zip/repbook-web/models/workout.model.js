class Workout {
    id;
    name;
    exercises = [];
    cardio = [];
    type;
    date;
}