﻿class Exercise {
    id;
    name;
    sets;
    reps;
    workoutId;

    constructor(name, sets, reps, workoutId) {
    this.id = generateGUID();
        this.name = name;
        this.sets = sets;
        this.reps = reps;
    }
}