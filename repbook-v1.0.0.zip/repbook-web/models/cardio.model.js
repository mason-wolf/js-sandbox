﻿class Cardio {
    id;
    name;
    distance;
    time;
    workoutId;

    constructor() {
        this.id = generateGUID();
    }
}